#!/bin/bash
#
# Enterprise-grade installer for the Velocity Network Manager Backend
#
# This script handles dependency checking, installation, and management
# of the Go backend required for the Velocity frontend to function.

# --- Safety Nets ---
# Exit immediately if a command exits with a non-zero status.
# Treat unset variables as an error when substituting.
# Pipelines return the exit code of the last command to exit with a non-zero status.
set -euo pipefail

# --- Configuration ---
readonly SCRIPT_NAME=$(basename "$0")
readonly START_DIR=$(pwd)
readonly REPO_URL="https://github.com/theoblignautza/Velocity-Version-2.git"
readonly INSTALL_DIR_NAME="velocity-backend"
readonly INSTALL_DIR="${START_DIR}/${INSTALL_DIR_NAME}"
readonly PID_FILE="${INSTALL_DIR}/velocity.pid"
readonly LOG_FILE="${INSTALL_DIR}/velocity.log"
readonly ERR_FILE="${INSTALL_DIR}/velocity.err"
readonly BACKEND_PORT="3000"
readonly REQUIRED_DEPS=("go" "git")

# --- Colors for Logging ---
readonly COLOR_RESET='\033[0m'
readonly COLOR_RED='\033[0;31m'
readonly COLOR_GREEN='\033[0;32m'
readonly COLOR_YELLOW='\033[0;33m'
readonly COLOR_BLUE='\033[0;34m'
readonly COLOR_CYAN='\033[0;36m'

# --- Helper Functions ---

# msg <color> <message>
# Prints a colored message to the console.
msg() {
    echo -e "${1}${2}${COLOR_RESET}"
}

# command_exists <command>
# Checks if a command is available in the system's PATH.
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# check_port <port>
# Checks if a given TCP port is in use.
check_port() {
    msg "${COLOR_BLUE}" "Checking if port ${1} is available..."
    # Use netstat as lsof may not be installed by default
    if command_exists netstat && netstat -tuln | grep -q ":${1}.*LISTEN"; then
        msg "${COLOR_RED}" "Error: Port ${1} is already in use by another application."
        msg "${COLOR_YELLOW}" "Please stop the other application or choose a different port before proceeding."
        exit 1
    fi
    msg "${COLOR_GREEN}" "Port ${1} is free."
}


# check_dependencies
# Verifies that all required tools are installed and prompts for installation if not.
check_dependencies() {
    msg "${COLOR_BLUE}" "Checking for required dependencies..."
    local missing_deps=()
    for dep in "${REQUIRED_DEPS[@]}"; do
        if ! command_exists "$dep"; then
            missing_deps+=("$dep")
        fi
    done

    if [ ${#missing_deps[@]} -ne 0 ]; then
        msg "${COLOR_YELLOW}" "The following dependencies are missing: ${missing_deps[*]}"
        
        local pm_base=""
        local pm_install_cmd=""
        if command_exists apt-get; then
            pm_base="apt-get"
            pm_install_cmd="sudo apt-get install -y"
        elif command_exists dnf; then
            pm_base="dnf"
            pm_install_cmd="sudo dnf install -y"
        elif command_exists yum; then
            pm_base="yum"
            pm_install_cmd="sudo yum install -y"
        elif command_exists brew; then
            pm_base="brew"
            pm_install_cmd="brew install"
        else
            msg "${COLOR_RED}" "Could not determine package manager. Please install the missing dependencies manually and run this script again."
            exit 1
        fi
        
        read -p "Would you like to try and install them now? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # For apt-based systems, always update first
            if [[ "$pm_base" == "apt-get" ]]; then
                msg "${COLOR_CYAN}" "Updating package lists with 'sudo apt-get update'. This may take a moment..."
                sudo apt-get update || { msg "${COLOR_YELLOW}" "Warning: 'apt-get update' failed. Proceeding anyway..."; }
            fi

            for dep in "${missing_deps[@]}"; do
                msg "${COLOR_CYAN}" "Attempting to install ${dep}..."
                # Special handling for Go on apt-based systems
                if [[ "$pm_base" == "apt-get" ]] && [[ "$dep" == "go" ]]; then
                    if sudo apt-get install -y golang-go; then
                        msg "${COLOR_GREEN}" "✓ Successfully installed 'golang-go'."
                    elif sudo apt-get install -y go; then
                         msg "${COLOR_GREEN}" "✓ Successfully installed 'go'."
                    else
                        msg "${COLOR_RED}" "✗ Failed to install Go using both 'golang-go' and 'go' package names. Please install it manually."
                        exit 1
                    fi
                else
                    # Standard installation for other deps or other package managers
                    ${pm_install_cmd} "${dep}" || { msg "${COLOR_RED}" "✗ Failed to install ${dep}. Please install it manually."; exit 1; }
                fi
            done
        else
            msg "${COLOR_RED}" "Installation aborted by user."
            exit 1
        fi
    fi
    msg "${COLOR_GREEN}" "All dependencies are satisfied."
}

# --- Main Functions ---

usage() {
    msg "${COLOR_CYAN}" "Velocity Backend Installer & Manager"
    msg "${COLOR_CYAN}" "------------------------------------"
    echo -e "Usage: ./${SCRIPT_NAME} [command]\n"
    echo "Commands:"
    msg "${COLOR_GREEN}" "  install    - Checks dependencies, clones the backend, and starts the server."
    msg "${COLOR_YELLOW}" "  uninstall  - Stops the server and removes all backend files."
    msg "${COLOR_BLUE}" "  status     - Checks if the backend server is currently running."
    msg "${COLOR_RED}" "  stop       - Stops the running backend server."
    msg "${COLOR_CYAN}" "  start      - Starts the backend server if it is installed but not running."
    echo "  help       - Shows this help message."
    echo
}

do_install() {
    msg "${COLOR_CYAN}" "Starting Velocity Backend installation..."
    
    if [ -d "${INSTALL_DIR}" ]; then
        msg "${COLOR_YELLOW}" "An existing installation was found at ${INSTALL_DIR}."
        read -p "Would you like to remove it and reinstall? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            do_uninstall
        else
            msg "${COLOR_RED}" "Installation aborted. Please use './${SCRIPT_NAME} start' to run the existing installation."
            exit 1
        fi
    fi

    check_dependencies
    check_port "${BACKEND_PORT}"

    msg "${COLOR_BLUE}" "Cloning backend repository from ${REPO_URL}..."
    git clone "${REPO_URL}" "${INSTALL_DIR}"
    
    cd "${INSTALL_DIR}"
    msg "${COLOR_BLUE}" "Searching for backend source directory..."
    # Find the directory containing main.go, which is the entrypoint.
    # Use find and handle potential multiple results or no results.
    local backend_src_dir_rel
    backend_src_dir_rel=$(find . -name "main.go" -printf '%h\n' | head -n 1)

    if [ -z "${backend_src_dir_rel}" ] || [ ! -d "${backend_src_dir_rel}" ]; then
        msg "${COLOR_RED}" "✗ Critical error: Could not find a directory containing 'main.go' in the repository."
        cd "${START_DIR}"
        rm -rf "${INSTALL_DIR}"
        exit 1
    fi

    msg "${COLOR_GREEN}" "✓ Found source directory at: ${backend_src_dir_rel}"
    cd "${backend_src_dir_rel}"
    
    msg "${COLOR_BLUE}" "Initializing Go module for the backend (running 'go mod init')..."
    go mod init velocity-backend >> "${LOG_FILE}" 2>> "${ERR_FILE}"
    
    msg "${COLOR_BLUE}" "Downloading backend dependencies (running 'go mod tidy')..."
    go mod tidy >> "${LOG_FILE}" 2>> "${ERR_FILE}"

    msg "${COLOR_BLUE}" "Starting the backend server in the background..."
    nohup go run . >> "${LOG_FILE}" 2>> "${ERR_FILE}" &
    local server_pid=$!
    
    sleep 2 # Give it a moment to start or fail

    if ps -p $server_pid > /dev/null; then
        echo $server_pid > "${PID_FILE}"
        msg "${COLOR_GREEN}" "✓ Installation complete!"
        msg "${COLOR_GREEN}" "Backend server is running with PID ${server_pid}."
        msg "${COLOR_YELLOW}" "Logs are available at ${LOG_FILE} and ${ERR_FILE}"
        msg "${COLOR_CYAN}" "You can now use the frontend application. It will connect to the backend automatically."
    else
        msg "${COLOR_RED}" "✗ Installation failed."
        msg "${COLOR_RED}" "The server failed to start. Check the error log for details:"
        cat "${ERR_FILE}"
        cd "${START_DIR}"
        rm -rf "${INSTALL_DIR}"
        exit 1
    fi
    cd "${START_DIR}"
}

do_uninstall() {
    msg "${COLOR_CYAN}" "Starting Velocity Backend uninstallation..."
    if [ ! -d "${INSTALL_DIR}" ]; then
        msg "${COLOR_YELLOW}" "No installation directory found. Nothing to do."
        return
    fi
    
    do_stop
    
    msg "${COLOR_BLUE}" "Removing installation directory: ${INSTALL_DIR}"
    rm -rf "${INSTALL_DIR}"
    
    msg "${COLOR_GREEN}" "✓ Uninstallation complete."
}

do_status() {
    if [ -f "${PID_FILE}" ]; then
        local pid
        pid=$(cat "${PID_FILE}")
        if ps -p "$pid" > /dev/null; then
            msg "${COLOR_GREEN}" "Backend server is RUNNING with PID ${pid}."
        else
            msg "${COLOR_YELLOW}" "Backend server is STOPPED, but a stale PID file was found."
            msg "${COLOR_YELLOW}" "Consider running the 'uninstall' command to clean up."
        fi
    else
        msg "${COLOR_RED}" "Backend server is STOPPED (No PID file found)."
    fi
}

do_stop() {
    if [ -f "${PID_FILE}" ]; then
        local pid
        pid=$(cat "${PID_FILE}")
        msg "${COLOR_BLUE}" "Stopping server process with PID ${pid}..."
        kill "$pid" 2>/dev/null || true # Kill the process and ignore errors if it's already gone
        sleep 1 # Wait a moment for it to shut down
        if ps -p "$pid" > /dev/null; then
            msg "${COLOR_YELLOW}" "Process did not stop gracefully. Forcing shutdown (kill -9)..."
            kill -9 "$pid" 2>/dev/null || true
        fi
        rm -f "${PID_FILE}"
        msg "${COLOR_GREEN}" "Server stopped."
    else
        msg "${COLOR_YELLOW}" "Server is not running (No PID file found)."
    fi
}

do_start() {
    if [ ! -d "${INSTALL_DIR}" ]; then
        msg "${COLOR_RED}" "Installation directory not found. Please run the 'install' command first."
        exit 1
    fi
    
    if [ -f "${PID_FILE}" ]; then
        msg "${COLOR_YELLOW}" "Server seems to be already running. Please check with the 'status' command."
        exit 1
    fi

    check_port "${BACKEND_PORT}"
    
    cd "${INSTALL_DIR}"
    local backend_src_dir_rel
    backend_src_dir_rel=$(find . -name "main.go" -printf '%h\n' | head -n 1)

    if [ -z "${backend_src_dir_rel}" ] || [ ! -d "${backend_src_dir_rel}" ]; then
        msg "${COLOR_RED}" "✗ Critical error: Could not find a directory containing 'main.go' in the installed files."
        cd "${START_DIR}"
        exit 1
    fi
    cd "${backend_src_dir_rel}"

    msg "${COLOR_BLUE}" "Starting the backend server in the background..."
    nohup go run . >> "${LOG_FILE}" 2>> "${ERR_FILE}" &
    local server_pid=$!
    sleep 2

    if ps -p $server_pid > /dev/null; then
        echo $server_pid > "${PID_FILE}"
        msg "${COLOR_GREEN}" "✓ Server started successfully with PID ${server_pid}."
    else
        msg "${COLOR_RED}" "✗ Server failed to start. Check the error log for details:"
        cat "${ERR_FILE}"
        cd "${START_DIR}"
        exit 1
    fi
    cd "${START_DIR}"
}


# --- Script Entrypoint ---

# Default to 'help' if no command is provided
COMMAND="${1:-help}"

case "${COMMAND}" in
    install)
        do_install
        ;;
    uninstall)
        do_uninstall
        ;;
    status)
        do_status
        ;;
    start)
        do_start
        ;;
    stop)
        do_stop
        ;;
    help|*)
        usage
        ;;
esac

exit 0
