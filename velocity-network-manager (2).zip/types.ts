
export interface Device {
  ID: number;
  Hostname: string;
  IPAddress: string;
  DeviceType: string;
  Username: string;
  Password?: string; 
}

export interface Template {
  ID: number;
  Name: string;
  Content: string;
}

export interface ComplianceReport {
  ID: number;
  DeviceID: number;
  TemplateID: number;
  Compliant: boolean;
  Report: string;
  Timestamp: string;
  Device?: Device;
  Template?: Template;
}
