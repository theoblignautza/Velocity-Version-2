
import React, { useState, useEffect, useCallback } from 'react';
import { getDevices, getTemplates } from '../services/api';
import { DeviceIcon, TemplateIcon, ComplianceIcon } from '../components/icons';
import { useNotifications } from '../hooks/useNotifications';

interface StatCardProps {
    icon: React.ReactNode;
    title: string;
    value: number | string;
    color: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, color }) => (
  <div className="bg-slate-800 rounded-lg p-6 flex items-center shadow-lg">
    <div className={`p-3 rounded-full mr-4 ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-slate-400">{title}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const [deviceCount, setDeviceCount] = useState(0);
  const [templateCount, setTemplateCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { addNotification } = useNotifications();

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [devices, templates] = await Promise.all([getDevices(), getTemplates()]);
      setDeviceCount(devices.length);
      setTemplateCount(templates.length);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      addNotification(errorMessage, 'error');
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const renderContent = () => {
    if (loading) {
      return <p>Loading stats...</p>;
    }
    if (error) {
      return (
        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
          <div className="mt-4">
            <button
              onClick={fetchData}
              className="px-4 py-2 bg-slate-600 text-white rounded-md hover:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-slate-500 transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      );
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard icon={<DeviceIcon />} title="Total Devices" value={deviceCount} color="bg-blue-500/30" />
        <StatCard icon={<TemplateIcon />} title="Total Templates" value={templateCount} color="bg-green-500/30" />
        <StatCard icon={<ComplianceIcon />} title="Compliance" value="N/A" color="bg-yellow-500/30" />
      </div>
    );
  };
  
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-white">Dashboard</h1>
      {renderContent()}
      <div className="mt-8 bg-slate-800 p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-semibold mb-4">Welcome to Velocity</h2>
        <p className="text-slate-300">
            This is your central hub for network device management. Use the sidebar to navigate between Devices, Templates, and Compliance checks.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
