
import type { BackupRequest, BackupResponse } from '../types';

export const performBackup = (request: BackupRequest): Promise<BackupResponse> => {
  // In a real application, this would be an HTTP POST request to the backend API.
  // e.g., fetch('/api/backup-config', { method: 'POST', body: JSON.stringify(request), ... })
  console.log('Sending backup request to mock backend:', { ...request, password: '***' });
  
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate a random success/failure for demonstration
      if (Math.random() > 0.2) { // 80% success rate
        const date = new Date();
        const dateString = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        
        resolve({
          status: 'success',
          device: request.device_ip,
          file: `running-config_${dateString}.txt`,
        });
      } else { // 20% failure rate
        reject({
          status: 'error',
          message: 'Failed to connect to device. Check credentials or network connectivity.',
          device: request.device_ip,
        });
      }
    }, 2500); // Simulate network delay
  });
};
   